const express = require('express')
const app = express()
const bodyparser = require("body-parser")

app.use(bodyparser.json())
app.use(bodyparser.urlencoded({extended:false}))

const {Client} = require('pg')
const client = new Client({
    host:"localhost",
    user:"postgres",
    port:5432,
    password:"postgres",
    database:"postgress"
})
let data={
    name:"aditya"
};

let datas ={
    name:"aditya"
}
client.connect();
client.query(`Select *from users`,(err,res)=>{
    if(!err){
        data=res.rows;
    }else{
        console.log(err.message);
    }
    client.end;
})

app.get('/api',(req,res)=>{
    res.json(datas);
})

app.post("/postreq",(req,res)=>{
    datas = req.body
    console.log("received response")
})


app.listen(5000)