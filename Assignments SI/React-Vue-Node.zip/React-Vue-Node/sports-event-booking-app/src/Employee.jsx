let Employee = () => {
  return <div>

    <h1 style={{ color: 'green', alignText: "center" }}>Employee Login</h1>
    <form style={{ display: "inline-grid", border: "2px solid black", padding: "20px", margin: "100px" }}>
      <div class="form-group">
        <label for="exampleInputEmail1">Email addresess</label>
        <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" />

      </div>
      <br />
      <div class="form-group">
        <label for="exampleInputPassword1">Password</label>
        <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password" />
      </div>
      <br />
      <button type="submit" class="btn btn-primary">Submit</button>
    </form>
  </div>
}
export default Employee;