import {BrowserRouter, Routes,Route} from "react-router-dom" ;
import Layout from "./Layout";
import Home from "./Home";
import Admin from "./Admin";
import Employee from "./Employee";
import axios from "axios"
import { useEffect, useState } from "react";


let App=()=>{

    let [data,setData]= useState([]);

    useEffect(()=>{
        axios.get("/api").then((res)=>{console.log(res.data.name)})
    })

    const message = () => {
        axios.post("/postreq",{name:"shruti"})
    }
    return <div >
        <button onClick={message}>CLick me</button>
        <BrowserRouter>
        <ul>{data.map(name => <li key={name.firstname}> {name.firstname}{name.lastname} </li>)}</ul>
        <Routes>
            <Route path="/" element={<Layout/>}> 
            <Route index element={<Home/>}/>
            <Route path="/admin" element ={<Admin/>}></Route>
            <Route path="/employee" element ={<Employee/>}></Route>
            <Route path="/home" element ={<Home/>}></Route>
            </Route>
        </Routes>
        </BrowserRouter>
    </div>
}
export default App;